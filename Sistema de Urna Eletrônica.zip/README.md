
  # Sistema de Urna Eletrônica

  This is a code bundle for Sistema de Urna Eletrônica. The original project is available at https://www.figma.com/design/tj0IQiNQ7QXafSr3FA0hnW/Sistema-de-Urna-Eletr%C3%B4nica.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  