import React, { useState } from 'react';
import { VotingScreen } from './components/VotingScreen';
import { LoginScreen } from './components/LoginScreen';
import { AdminPanel } from './components/AdminPanel';
import { Button } from './components/ui/button';
import { Settings, Vote, LogOut } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'voting' | 'login' | 'admin'>('voting');
  const [adminToken, setAdminToken] = useState<string | null>(null);

  const handleLogin = (token: string) => {
    setAdminToken(token);
    setCurrentScreen('admin');
  };

  const handleLogout = () => {
    setAdminToken(null);
    setCurrentScreen('voting');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Vote className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-semibold text-gray-900">Sistema de Votação Eletrônica</h1>
                <p className="text-sm text-gray-500">Eleições 2024</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              {currentScreen === 'voting' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentScreen('login')}
                  className="flex items-center space-x-2"
                >
                  <Settings className="w-4 h-4" />
                  <span>Admin</span>
                </Button>
              )}
              
              {adminToken && currentScreen === 'admin' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLogout}
                  className="flex items-center space-x-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sair</span>
                </Button>
              )}
              
              {currentScreen !== 'voting' && !adminToken && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentScreen('voting')}
                  className="flex items-center space-x-2"
                >
                  <Vote className="w-4 h-4" />
                  <span>Voltar à Votação</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {currentScreen === 'voting' && <VotingScreen />}
        {currentScreen === 'login' && <LoginScreen onLogin={handleLogin} />}
        {currentScreen === 'admin' && adminToken && <AdminPanel adminToken={adminToken} />}
      </main>
    </div>
  );
}