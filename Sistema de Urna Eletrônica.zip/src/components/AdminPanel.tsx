import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Users, 
  TrendingUp, 
  Plus, 
  Edit, 
  Trash2, 
  Vote,
  FileText,
  BarChart3,
  Loader2,
  RefreshCw,
  RotateCcw
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Candidate {
  id: string;
  name: string;
  party: string;
  number: string;
  photo: string;
  votes: number;
}

interface VoteStats {
  totalVotes: number;
  blankVotes: number;
  nullVotes: number;
  validVotes: number;
}

interface AdminPanelProps {
  adminToken: string;
}

export function AdminPanel({ adminToken }: AdminPanelProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [stats, setStats] = useState<VoteStats>({
    totalVotes: 0,
    blankVotes: 0,
    nullVotes: 0,
    validVotes: 0
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newCandidate, setNewCandidate] = useState({
    name: '',
    party: '',
    number: '',
    photo: ''
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [lastRefresh, setLastRefresh] = useState<number>(0);

  // Load data only once on mount, then manual refresh only
  useEffect(() => {
    loadData();
  }, []);

  // Clear success message after 3 seconds
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => setSuccess(''), 3000);
      return () => clearTimeout(timer);
    }
  }, [success]);

  const loadData = async () => {
    try {
      setError('');
      const now = Date.now();
      
      // Prevent too frequent refreshes
      if (now - lastRefresh < 2000) {
        console.log('Refresh rate limited');
        return;
      }
      
      const refreshing = candidates.length > 0;
      if (refreshing) setIsRefreshing(true);
      else setIsLoading(true);

      console.log('Loading admin data...');

      // Load results (candidates + stats)
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-4b7b6120/results`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Admin data loaded:', data);
        
        // Filter and validate candidates
        const validCandidates = (data.candidates || []).filter((candidate: any) => 
          candidate && 
          candidate.id && 
          candidate.name && 
          candidate.number &&
          typeof candidate.id === 'string' &&
          typeof candidate.name === 'string' &&
          typeof candidate.number === 'string'
        ).map((candidate: any) => ({
          ...candidate,
          votes: candidate.votes || 0,
          party: candidate.party || '',
          photo: candidate.photo || ''
        }));

        setCandidates(validCandidates);
        setStats(data.stats || {
          totalVotes: 0,
          blankVotes: 0,
          nullVotes: 0,
          validVotes: 0
        });
        
        setLastRefresh(now);
      } else {
        const errorData = await response.json();
        console.error('Error loading admin data:', errorData);
        setError(errorData.error || 'Erro ao carregar dados');
      }
    } catch (error) {
      console.error('Network error loading admin data:', error);
      setError('Erro de conexão ao carregar dados');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleAddCandidate = async () => {
    try {
      setError('');
      setSuccess('');
      setIsAdding(true);
      
      // Validate required fields
      if (!newCandidate.name.trim() || !newCandidate.party.trim() || !newCandidate.number.trim()) {
        setError('Nome, partido e número são obrigatórios');
        return;
      }

      // Validate number format
      if (!/^\d{1,2}$/.test(newCandidate.number)) {
        setError('O número deve conter apenas dígitos (1-2 caracteres)');
        return;
      }

      // Check if number already exists
      if (candidates.some(c => c.number === newCandidate.number)) {
        setError('Este número já está sendo usado por outro candidato');
        return;
      }

      console.log('Adding candidate:', newCandidate);

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-4b7b6120/candidates`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          name: newCandidate.name.trim(),
          party: newCandidate.party.trim(),
          number: newCandidate.number.trim(),
          photo: newCandidate.photo.trim()
        })
      });

      if (response.ok) {
        const candidate = await response.json();
        console.log('Candidate added successfully:', candidate);
        
        if (candidate && candidate.id) {
          // Update local state immediately
          setCandidates(prev => [...prev, candidate]);
          setNewCandidate({ name: '', party: '', number: '', photo: '' });
          setIsAddDialogOpen(false);
          setSuccess('Candidato adicionado com sucesso!');
        }
      } else {
        const errorData = await response.json();
        console.error('Error adding candidate:', errorData);
        setError(errorData.error || 'Erro ao adicionar candidato');
      }
    } catch (error) {
      console.error('Network error adding candidate:', error);
      setError('Erro de conexão ao adicionar candidato');
    } finally {
      setIsAdding(false);
    }
  };

  const handleDeleteCandidate = async (id: string, name: string) => {
    if (!id) return;
    
    if (!confirm(`Tem certeza que deseja excluir o candidato ${name}?`)) {
      return;
    }
    
    try {
      setError('');
      setSuccess('');
      
      console.log('Deleting candidate:', id);

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-4b7b6120/candidates/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${adminToken}` }
      });

      if (response.ok) {
        console.log('Candidate deleted successfully');
        // Update local state immediately
        setCandidates(prev => prev.filter(c => c && c.id !== id));
        setSuccess('Candidato excluído com sucesso!');
      } else {
        const errorData = await response.json();
        console.error('Error deleting candidate:', errorData);
        setError(errorData.error || 'Erro ao deletar candidato');
      }
    } catch (error) {
      console.error('Network error deleting candidate:', error);
      setError('Erro de conexão ao deletar candidato');
    }
  };

  const handleResetSystem = async () => {
    if (!confirm('ATENÇÃO: Isso irá excluir TODOS os candidatos e votos. Esta ação não pode ser desfeita. Continuar?')) {
      return;
    }

    try {
      setError('');
      setSuccess('');
      setIsResetting(true);

      console.log('Resetting system...');

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-4b7b6120/reset`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${adminToken}` }
      });

      if (response.ok) {
        console.log('System reset successfully');
        setCandidates([]);
        setStats({
          totalVotes: 0,
          blankVotes: 0,
          nullVotes: 0,
          validVotes: 0
        });
        setSuccess('Sistema resetado com sucesso!');
      } else {
        const errorData = await response.json();
        console.error('Error resetting system:', errorData);
        setError(errorData.error || 'Erro ao resetar sistema');
      }
    } catch (error) {
      console.error('Network error resetting system:', error);
      setError('Erro de conexão ao resetar sistema');
    } finally {
      setIsResetting(false);
    }
  };

  const getVotePercentage = (votes: number) => {
    return stats.validVotes > 0 ? ((votes / stats.validVotes) * 100).toFixed(1) : '0.0';
  };

  // Sort candidates by votes, filtering out any null/undefined ones
  const sortedCandidates = candidates
    .filter(candidate => candidate && candidate.id)
    .sort((a, b) => (b.votes || 0) - (a.votes || 0));

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8">
            <Loader2 className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-spin" />
            <h2 className="text-2xl mb-2">Carregando Painel</h2>
            <p className="text-gray-600">Obtendo dados administrativos...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2">Painel Administrativo</h1>
            <p className="text-gray-600">Gerencie candidatos e acompanhe os resultados em tempo real</p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={loadData}
              disabled={isRefreshing}
              className="flex items-center space-x-2"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>Atualizar</span>
            </Button>
            <Button
              variant="destructive"
              onClick={handleResetSystem}
              disabled={isResetting}
              className="flex items-center space-x-2"
            >
              <RotateCcw className={`w-4 h-4 ${isResetting ? 'animate-spin' : ''}`} />
              <span>{isResetting ? 'Resetando...' : 'Reset Sistema'}</span>
            </Button>
          </div>
        </div>

        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total de Votos</p>
                  <p className="text-2xl font-semibold">{stats.totalVotes.toLocaleString()}</p>
                </div>
                <Vote className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Votos Válidos</p>
                  <p className="text-2xl font-semibold">{stats.validVotes.toLocaleString()}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Votos em Branco</p>
                  <p className="text-2xl font-semibold">{stats.blankVotes}</p>
                </div>
                <FileText className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Candidatos</p>
                  <p className="text-2xl font-semibold">{candidates.length}</p>
                </div>
                <Users className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="candidates" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="candidates" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Candidatos</span>
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span>Resultados</span>
            </TabsTrigger>
          </TabsList>

          {/* Candidates Tab */}
          <TabsContent value="candidates" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="w-5 h-5" />
                    <span>Gerenciar Candidatos</span>
                  </CardTitle>
                  <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="flex items-center space-x-2">
                        <Plus className="w-4 h-4" />
                        <span>Adicionar</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Adicionar Novo Candidato</DialogTitle>
                        <DialogDescription>
                          Preencha os dados do novo candidato para a eleição.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Nome *</Label>
                          <Input
                            id="name"
                            value={newCandidate.name}
                            onChange={(e) => setNewCandidate({ ...newCandidate, name: e.target.value })}
                            placeholder="Nome completo do candidato"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="party">Partido *</Label>
                          <Input
                            id="party"
                            value={newCandidate.party}
                            onChange={(e) => setNewCandidate({ ...newCandidate, party: e.target.value })}
                            placeholder="Nome do partido político"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="number">Número *</Label>
                          <Input
                            id="number"
                            value={newCandidate.number}
                            onChange={(e) => setNewCandidate({ ...newCandidate, number: e.target.value.replace(/\D/g, '') })}
                            placeholder="Número do candidato (ex: 15)"
                            maxLength={2}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="photo">URL da Foto</Label>
                          <Input
                            id="photo"
                            value={newCandidate.photo}
                            onChange={(e) => setNewCandidate({ ...newCandidate, photo: e.target.value })}
                            placeholder="https://example.com/foto.jpg (opcional)"
                          />
                        </div>
                        <Button 
                          onClick={handleAddCandidate} 
                          className="w-full"
                          disabled={isAdding}
                        >
                          {isAdding ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Adicionando...
                            </>
                          ) : (
                            'Adicionar Candidato'
                          )}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {candidates.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">Nenhum candidato disponível.</p>
                    <p className="text-sm text-gray-500 mt-2">Adicione candidatos usando o botão acima.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {candidates.map((candidate) => (
                      candidate && candidate.id ? (
                        <div
                          key={candidate.id}
                          className="flex items-center justify-between p-4 border rounded-lg"
                        >
                          <div className="flex items-center space-x-4">
                            <ImageWithFallback
                              src={candidate.photo || ''}
                              alt={candidate.name || 'Candidato'}
                              className="w-12 h-12 rounded-full object-cover"
                            />
                            <div>
                              <div className="flex items-center space-x-2 mb-1">
                                <Badge variant="outline">{candidate.number}</Badge>
                                <h3 className="font-semibold">{candidate.name}</h3>
                              </div>
                              <p className="text-sm text-gray-600">{candidate.party}</p>
                              <p className="text-xs text-gray-500">{candidate.votes || 0} votos</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteCandidate(candidate.id, candidate.name)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ) : null
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Resultados da Eleição</span>
                  {isRefreshing && <Loader2 className="w-4 h-4 animate-spin text-blue-500" />}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {sortedCandidates.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">Nenhum candidato disponível.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {sortedCandidates.map((candidate, index) => (
                      <div
                        key={candidate.id}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <Badge variant={index === 0 ? "default" : "secondary"}>
                            {index + 1}º
                          </Badge>
                          <ImageWithFallback
                            src={candidate.photo || ''}
                            alt={candidate.name || 'Candidato'}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          <div>
                            <h3 className="font-semibold">{candidate.name}</h3>
                            <p className="text-sm text-gray-600">{candidate.party}</p>
                            <p className="text-xs text-gray-500">Número: {candidate.number}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-semibold">{(candidate.votes || 0).toLocaleString()}</p>
                          <p className="text-sm text-gray-600">{getVotePercentage(candidate.votes || 0)}%</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}