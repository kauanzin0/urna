import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle, User, ArrowRight, RotateCcw, Loader2 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Candidate {
  id: string;
  name: string;
  party: string;
  number: string;
  photo: string;
  votes: number;
}

export function VotingScreen() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [voteSubmitted, setVoteSubmitted] = useState(false);
  const [enteredNumber, setEnteredNumber] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [hasInitialized, setHasInitialized] = useState(false);

  // Load candidates only once when component mounts
  useEffect(() => {
    if (!hasInitialized) {
      loadCandidates();
      setHasInitialized(true);
    }
  }, [hasInitialized]);

  const loadCandidates = async () => {
    try {
      setIsLoading(true);
      setError('');

      console.log('Loading candidates...');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-4b7b6120/candidates`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });

      if (response.ok) {
        const candidatesData = await response.json();
        console.log('Raw candidates data:', candidatesData);
        
        // Filter and validate candidates
        const validCandidates = (Array.isArray(candidatesData) ? candidatesData : []).filter((candidate: any) => 
          candidate && 
          candidate.id && 
          candidate.name && 
          candidate.number &&
          typeof candidate.id === 'string' &&
          typeof candidate.name === 'string' &&
          typeof candidate.number === 'string'
        ).map((candidate: any) => ({
          ...candidate,
          votes: candidate.votes || 0,
          party: candidate.party || '',
          photo: candidate.photo || ''
        }));
        
        console.log('Valid candidates:', validCandidates);
        setCandidates(validCandidates);
        
        if (validCandidates.length === 0) {
          console.log('No candidates found, system may need initialization');
        }
      } else {
        const errorData = await response.json();
        console.error('Error loading candidates:', errorData);
        setError(errorData.error || 'Erro ao carregar candidatos');
      }
    } catch (error) {
      console.error('Network error loading candidates:', error);
      setError('Erro de conexão ao carregar candidatos');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNumberInput = (number: string) => {
    if (enteredNumber.length < 2) {
      const newNumber = enteredNumber + number;
      setEnteredNumber(newNumber);
      
      if (newNumber.length === 2) {
        const candidate = candidates.find(c => c && c.number === newNumber);
        setSelectedCandidate(candidate || null);
      }
    }
  };

  const handleConfirm = async () => {
    if (selectedCandidate && !showConfirmation) {
      setShowConfirmation(true);
    } else if (showConfirmation) {
      await submitVote();
    }
  };

  const submitVote = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      const voteData = {
        candidateId: selectedCandidate?.id || null,
        voteType: enteredNumber === 'BRANCO' ? 'blank' : selectedCandidate ? 'candidate' : 'null'
      };

      console.log('Submitting vote:', voteData);

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-4b7b6120/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(voteData)
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Vote submitted successfully:', result);
        setVoteSubmitted(true);
        setTimeout(() => {
          handleReset();
        }, 3000);
      } else {
        const errorData = await response.json();
        console.error('Error submitting vote:', errorData);
        setError(errorData.error || 'Erro ao registrar voto');
        setShowConfirmation(false);
      }
    } catch (error) {
      console.error('Network error submitting vote:', error);
      setError('Erro de conexão ao registrar voto');
      setShowConfirmation(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSelectedCandidate(null);
    setShowConfirmation(false);
    setVoteSubmitted(false);
    setEnteredNumber('');
    setError('');
  };

  const handleBlankVote = () => {
    setSelectedCandidate(null);
    setEnteredNumber('BRANCO');
    setShowConfirmation(true);
  };

  const handleRetry = () => {
    setError('');
    setHasInitialized(false); // This will trigger a reload
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8">
            <Loader2 className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-spin" />
            <h2 className="text-2xl mb-2">Carregando Sistema</h2>
            <p className="text-gray-600">Preparando urna eletrônica...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (voteSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl mb-2 text-green-700">Voto Registrado!</h2>
            <p className="text-gray-600">Obrigado por participar do processo democrático.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-6xl mx-auto">
        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertDescription className="text-red-800">
              {error}
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleRetry} 
                className="ml-4"
              >
                Tentar Novamente
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Side - Candidate Selection */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>Prefeito</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {candidates.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">Nenhum candidato disponível no momento.</p>
                    <p className="text-sm text-gray-500 mt-2">
                      Verifique se o sistema foi configurado pelo administrador.
                    </p>
                    <Button 
                      variant="outline" 
                      onClick={handleRetry} 
                      className="mt-4"
                    >
                      Recarregar Candidatos
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {candidates.map((candidate) => (
                      candidate && candidate.id ? (
                        <div
                          key={candidate.id}
                          className={`p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md ${
                            selectedCandidate?.id === candidate.id
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => {
                            setSelectedCandidate(candidate);
                            setEnteredNumber(candidate.number);
                          }}
                        >
                          <div className="flex items-center space-x-4">
                            <ImageWithFallback
                              src={candidate.photo || ''}
                              alt={candidate.name || 'Candidato'}
                              className="w-16 h-16 rounded-full object-cover"
                            />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <Badge variant="outline" className="bg-blue-100 text-blue-800">
                                  {candidate.number}
                                </Badge>
                                <h3 className="font-semibold">{candidate.name}</h3>
                              </div>
                              <p className="text-sm text-gray-600">{candidate.party || ''}</p>
                            </div>
                            {selectedCandidate?.id === candidate.id && (
                              <CheckCircle className="w-6 h-6 text-blue-500" />
                            )}
                          </div>
                        </div>
                      ) : null
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Side - Numeric Keypad and Confirmation */}
          <div className="space-y-6">
            {/* Number Display */}
            <Card>
              <CardHeader>
                <CardTitle>Digite o número do candidato</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-black text-green-400 p-4 rounded-lg mb-4 font-mono text-center">
                  <div className="text-3xl tracking-wider min-h-[40px] flex items-center justify-center">
                    {enteredNumber || '__'}
                  </div>
                </div>
                
                {selectedCandidate && (
                  <Alert className="border-blue-200 bg-blue-50">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-blue-800">
                      Candidato selecionado: <strong>{selectedCandidate.name}</strong>
                    </AlertDescription>
                  </Alert>
                )}
                
                {enteredNumber.length === 2 && !selectedCandidate && enteredNumber !== 'BRANCO' && (
                  <Alert className="border-yellow-200 bg-yellow-50">
                    <AlertDescription className="text-yellow-800">
                      Número não encontrado. Verifique o número digitado.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Numeric Keypad */}
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                    <Button
                      key={num}
                      variant="outline"
                      size="lg"
                      className="h-16 text-xl"
                      onClick={() => handleNumberInput(num.toString())}
                      disabled={showConfirmation || isSubmitting}
                    >
                      {num}
                    </Button>
                  ))}
                  <Button
                    variant="outline"
                    size="lg"
                    className="h-16 text-xl"
                    onClick={() => handleNumberInput('0')}
                    disabled={showConfirmation || isSubmitting}
                  >
                    0
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={handleReset}
                    disabled={voteSubmitted || isSubmitting}
                    className="flex items-center justify-center space-x-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Corrigir</span>
                  </Button>
                  
                  <Button
                    variant="secondary"
                    size="lg"
                    onClick={handleBlankVote}
                    disabled={showConfirmation || voteSubmitted || isSubmitting}
                  >
                    Voto em Branco
                  </Button>
                </div>
                
                <Button
                  size="lg"
                  className="w-full mt-4"
                  onClick={handleConfirm}
                  disabled={(!selectedCandidate && enteredNumber !== 'BRANCO') || voteSubmitted || isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Registrando...
                    </>
                  ) : showConfirmation ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Confirmar Voto
                    </>
                  ) : (
                    <>
                      <ArrowRight className="w-4 h-4 mr-2" />
                      Continuar
                    </>
                  )}
                </Button>
                
                {showConfirmation && (
                  <Alert className="mt-4 border-green-200 bg-green-50">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                      {enteredNumber === 'BRANCO' 
                        ? 'Confirme seu voto em branco'
                        : `Confirme seu voto para ${selectedCandidate?.name}`}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}