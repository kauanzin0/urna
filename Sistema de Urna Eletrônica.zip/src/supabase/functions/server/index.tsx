import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL'),
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'),
);

// Admin authentication
app.post('/make-server-4b7b6120/auth/login', async (c) => {
  try {
    const { username, password } = await c.req.json();
    console.log('Login attempt for:', username);
    
    if (username === 'admin' && password === 'admin123') {
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email: 'admin@voting.com',
        password: 'admin123456'
      });
      
      if (error) {
        console.log('Creating admin user...');
        const { data: adminUser, error: createError } = await supabase.auth.admin.createUser({
          email: 'admin@voting.com',
          password: 'admin123456',
          user_metadata: { name: 'Administrator', role: 'admin' },
          email_confirm: true
        });
        
        if (createError && !createError.message.includes('already registered')) {
          console.log('Error creating admin user:', createError);
          return c.json({ error: 'Erro interno do servidor' }, 500);
        }
        
        const { data: { session: newSession }, error: signInError } = await supabase.auth.signInWithPassword({
          email: 'admin@voting.com',
          password: 'admin123456'
        });
        
        if (signInError) {
          console.log('Error signing in admin:', signInError);
          return c.json({ error: 'Credenciais inválidas' }, 401);
        }
        
        return c.json({ success: true, token: newSession?.access_token });
      }
      
      return c.json({ success: true, token: session?.access_token });
    }
    
    return c.json({ error: 'Credenciais inválidas' }, 401);
  } catch (error) {
    console.log('Login error:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

// Get all candidates
app.get('/make-server-4b7b6120/candidates', async (c) => {
  try {
    console.log('Getting all candidates...');
    const candidates = await kv.getByPrefix('candidate:');
    console.log('Raw candidates from KV:', candidates);
    
    const validCandidates = candidates
      .map(item => item.value)
      .filter(candidate => {
        const isValid = candidate && 
          candidate.id && 
          candidate.name && 
          candidate.number &&
          typeof candidate.id === 'string' &&
          typeof candidate.name === 'string' &&
          typeof candidate.number === 'string';
        
        if (!isValid) {
          console.log('Invalid candidate filtered out:', candidate);
        }
        return isValid;
      });
    
    console.log('Valid candidates found:', validCandidates.length);
    
    // Initialize with default candidates only if NO candidates exist at all
    if (validCandidates.length === 0) {
      console.log('No candidates found, checking if we should initialize defaults...');
      
      // Check if we've ever had candidates before by looking for a system flag
      const systemInitialized = await kv.get('system_initialized');
      if (!systemInitialized) {
        console.log('System not initialized, creating default candidates...');
        const defaultCandidates = await initializeDefaultCandidates();
        await kv.set('system_initialized', true);
        return c.json(defaultCandidates);
      }
    }
    
    return c.json(validCandidates);
  } catch (error) {
    console.log('Error fetching candidates:', error);
    return c.json({ error: 'Erro ao buscar candidatos' }, 500);
  }
});

// Add new candidate
app.post('/make-server-4b7b6120/candidates', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Não autorizado' }, 401);
    }
    
    const candidate = await c.req.json();
    console.log('Adding new candidate:', candidate);
    
    // Validate required fields
    if (!candidate.name?.trim() || !candidate.party?.trim() || !candidate.number?.trim()) {
      return c.json({ error: 'Todos os campos obrigatórios devem ser preenchidos' }, 400);
    }
    
    // Check if candidate number already exists
    const existingCandidates = await kv.getByPrefix('candidate:');
    const numberExists = existingCandidates.some(item => 
      item.value && item.value.number === candidate.number.trim()
    );
    
    if (numberExists) {
      return c.json({ error: 'Número do candidato já existe' }, 400);
    }
    
    const candidateWithId = {
      id: `candidate_${Date.now()}_${Math.random().toString(36).substring(2)}`,
      name: candidate.name.trim(),
      party: candidate.party.trim(),
      number: candidate.number.trim(),
      photo: candidate.photo?.trim() || '',
      votes: 0,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`candidate:${candidateWithId.id}`, candidateWithId);
    console.log('Candidate added successfully:', candidateWithId);
    
    return c.json(candidateWithId);
  } catch (error) {
    console.log('Error adding candidate:', error);
    return c.json({ error: 'Erro ao adicionar candidato' }, 500);
  }
});

// Update candidate
app.put('/make-server-4b7b6120/candidates/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Não autorizado' }, 401);
    }
    
    const id = c.req.param('id');
    const updates = await c.req.json();
    
    const existingCandidate = await kv.get(`candidate:${id}`);
    if (!existingCandidate) {
      return c.json({ error: 'Candidato não encontrado' }, 404);
    }
    
    const updatedCandidate = { ...existingCandidate, ...updates };
    await kv.set(`candidate:${id}`, updatedCandidate);
    
    console.log('Candidate updated:', updatedCandidate);
    return c.json(updatedCandidate);
  } catch (error) {
    console.log('Error updating candidate:', error);
    return c.json({ error: 'Erro ao atualizar candidato' }, 500);
  }
});

// Delete candidate
app.delete('/make-server-4b7b6120/candidates/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Não autorizado' }, 401);
    }
    
    const id = c.req.param('id');
    const candidate = await kv.get(`candidate:${id}`);
    
    if (!candidate) {
      return c.json({ error: 'Candidato não encontrado' }, 404);
    }
    
    await kv.del(`candidate:${id}`);
    console.log('Candidate deleted:', id);
    
    return c.json({ success: true });
  } catch (error) {
    console.log('Error deleting candidate:', error);
    return c.json({ error: 'Erro ao deletar candidato' }, 500);
  }
});

// Cast vote
app.post('/make-server-4b7b6120/vote', async (c) => {
  try {
    const { candidateId, voteType } = await c.req.json();
    console.log('Casting vote:', { candidateId, voteType });
    
    const voteId = `vote_${Date.now()}_${Math.random().toString(36).substring(2)}`;
    const vote = {
      id: voteId,
      candidateId,
      voteType, // 'candidate', 'blank', or 'null'
      timestamp: new Date().toISOString(),
      ipAddress: c.req.header('x-forwarded-for') || 'unknown'
    };
    
    await kv.set(`vote:${voteId}`, vote);
    console.log('Vote recorded:', vote);
    
    // Update candidate vote count if it's a valid vote
    if (voteType === 'candidate' && candidateId) {
      const candidate = await kv.get(`candidate:${candidateId}`);
      if (candidate) {
        candidate.votes = (candidate.votes || 0) + 1;
        await kv.set(`candidate:${candidateId}`, candidate);
        console.log('Updated candidate votes:', candidate);
      }
    }
    
    // Update vote statistics
    const stats = await kv.get('vote_stats') || {
      totalVotes: 0,
      validVotes: 0,
      blankVotes: 0,
      nullVotes: 0
    };
    
    stats.totalVotes += 1;
    if (voteType === 'candidate') stats.validVotes += 1;
    else if (voteType === 'blank') stats.blankVotes += 1;
    else if (voteType === 'null') stats.nullVotes += 1;
    
    await kv.set('vote_stats', stats);
    console.log('Updated vote stats:', stats);
    
    return c.json({ success: true, voteId });
  } catch (error) {
    console.log('Error casting vote:', error);
    return c.json({ error: 'Erro ao registrar voto' }, 500);
  }
});

// Get vote statistics
app.get('/make-server-4b7b6120/stats', async (c) => {
  try {
    const stats = await kv.get('vote_stats') || {
      totalVotes: 0,
      validVotes: 0,
      blankVotes: 0,
      nullVotes: 0
    };
    
    return c.json(stats);
  } catch (error) {
    console.log('Error fetching stats:', error);
    return c.json({ error: 'Erro ao buscar estatísticas' }, 500);
  }
});

// Get election results
app.get('/make-server-4b7b6120/results', async (c) => {
  try {
    console.log('Getting election results...');
    
    const candidates = await kv.getByPrefix('candidate:');
    const stats = await kv.get('vote_stats') || {
      totalVotes: 0,
      validVotes: 0,
      blankVotes: 0,
      nullVotes: 0
    };
    
    const validCandidates = candidates
      .map(item => item.value)
      .filter(candidate => candidate && candidate.id)
      .sort((a, b) => (b.votes || 0) - (a.votes || 0));
    
    console.log('Results:', { candidatesCount: validCandidates.length, stats });
    
    return c.json({
      candidates: validCandidates,
      stats
    });
  } catch (error) {
    console.log('Error fetching results:', error);
    return c.json({ error: 'Erro ao buscar resultados' }, 500);
  }
});

// Helper function to initialize default candidates
async function initializeDefaultCandidates() {
  try {
    console.log('Initializing default candidates...');
    const defaultCandidates = [
      {
        id: 'candidate_default_1',
        name: 'Maria Silva',
        party: 'Partido da Esperança',
        number: '15',
        photo: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
        votes: 0,
        createdAt: new Date().toISOString()
      },
      {
        id: 'candidate_default_2',
        name: 'João Santos',
        party: 'Movimento Democrático',
        number: '22',
        photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
        votes: 0,
        createdAt: new Date().toISOString()
      },
      {
        id: 'candidate_default_3',
        name: 'Ana Costa',
        party: 'Partido do Progresso',
        number: '45',
        photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
        votes: 0,
        createdAt: new Date().toISOString()
      }
    ];
    
    for (const candidate of defaultCandidates) {
      await kv.set(`candidate:${candidate.id}`, candidate);
    }
    
    console.log('Default candidates initialized successfully');
    return defaultCandidates;
  } catch (error) {
    console.log('Error initializing default candidates:', error);
    return [];
  }
}

// Reset system - for testing purposes (admin only)
app.post('/make-server-4b7b6120/reset', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Não autorizado' }, 401);
    }
    
    console.log('Resetting system...');
    
    // Delete all candidates and votes
    const candidates = await kv.getByPrefix('candidate:');
    const votes = await kv.getByPrefix('vote:');
    
    for (const candidate of candidates) {
      await kv.del(candidate.key);
    }
    
    for (const vote of votes) {
      await kv.del(vote.key);
    }
    
    // Reset stats and system flag
    await kv.set('vote_stats', {
      totalVotes: 0,
      validVotes: 0,
      blankVotes: 0,
      nullVotes: 0
    });
    
    await kv.del('system_initialized');
    
    console.log('System reset completed');
    return c.json({ message: 'Sistema resetado com sucesso' });
  } catch (error) {
    console.log('Error resetting system:', error);
    return c.json({ error: 'Erro ao resetar sistema' }, 500);
  }
});

Deno.serve(app.fetch);